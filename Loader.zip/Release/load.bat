@echo off
@echo off
title Driver Loader
color 0A

:: ── Force run as admin ────────────────────────────────────────
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Requesting administrator privileges...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    pushd "%CD%"
    CD /D "%~dp0"

echo =======================================
echo        PhantomWare Driver Loader
echo =======================================
echo.
echo [OK] Running as administrator
echo.

:: Check if files exist
if not exist "kdmapper_Release.exe" (
    echo [ERROR] kdmapper_Release.exe not found!
    echo Make sure it is in the same folder as this bat file.
    echo.
    pause
    exit
)

if not exist "Driver.sys" (
    echo [ERROR] Driver.sys not found!
    echo Make sure it is in the same folder as this bat file.
    echo.
    pause
    exit
)

echo [OK] kdmapper_Release.exe found
echo [OK] Driver.sys found
echo.
echo Loading driver...
echo.

:: Run kdmapper and capture exit code
kdmapper_Release.exe Driver.sys
set EXIT_CODE=%errorlevel%

echo.
echo =======================================

if %EXIT_CODE% == 0 (
    echo [SUCCESS] Driver loaded successfully!
    echo Exit code: %EXIT_CODE%
) else (
    echo [FAILED] Driver failed to load!
    echo Exit code: %EXIT_CODE%
    echo.
    echo Common reasons:
    echo  - Secure Boot is enabled in BIOS
    echo  - Another instance of the driver is already loaded
    echo  - Antivirus blocked kdmapper
    echo  - Windows version not supported
)

echo =======================================
echo.
pause